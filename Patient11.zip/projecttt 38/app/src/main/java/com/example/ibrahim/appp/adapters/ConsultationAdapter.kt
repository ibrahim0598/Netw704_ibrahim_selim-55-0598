package com.example.ibrahim.appp.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.ibrahim.appp.databinding.ItemConsultationBinding
import com.example.ibrahim.appp.models.ConsultationRequest

class ConsultationAdapter(
    private val consultations: List<ConsultationRequest>, // List of consultations
    private val onItemClicked: (ConsultationRequest) -> Unit // Callback for item clicks
) : RecyclerView.Adapter<ConsultationAdapter.ConsultationViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ConsultationViewHolder {
        val binding = ItemConsultationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ConsultationViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ConsultationViewHolder, position: Int) {
        val consultation = consultations[position]
        holder.bind(consultation)
    }

    override fun getItemCount() = consultations.size

    inner class ConsultationViewHolder(private val binding: ItemConsultationBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(consultation: ConsultationRequest) {
            // Display consultation details
            binding.consultationStatusTextView.text = "Status: ${consultation.status}"
            binding.consultationResponseTextView.text = "Response: ${consultation.response}"
            binding.consultationDateTextView.text = "Date: ${consultation.date}"

            // Handle item click for additional actions
            binding.root.setOnClickListener {
                onItemClicked(consultation)
            }
        }
    }
}
