package com.example.ibrahim.appp.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ibrahim.appp.adapters.ReviewAdapter
import com.example.ibrahim.appp.databinding.FragmentReviewBinding
import com.example.ibrahim.appp.models.ReviewItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class ReviewFragment : Fragment() {

    private lateinit var binding: FragmentReviewBinding
    private lateinit var reviewAdapter: ReviewAdapter
    private val reviewItems = mutableListOf<ReviewItem>()
    private lateinit var databaseReference: DatabaseReference
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentReviewBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        fetchReviewItems()
    }

    private fun setupRecyclerView() {
        reviewAdapter = ReviewAdapter(reviewItems) { reviewItem, action ->
            when (action) {
                ReviewAdapter.Action.APPROVE -> updateReviewStatus(reviewItem, "approved")
                ReviewAdapter.Action.DECLINE -> updateReviewStatus(reviewItem, "declined")
                ReviewAdapter.Action.RESPOND -> handleRespondAction(reviewItem)
            }
        }
        binding.reviewRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.reviewRecyclerView.adapter = reviewAdapter
    }

    private fun fetchReviewItems() {
        showLoading(true)

        val doctorId = auth.currentUser?.uid
        if (doctorId.isNullOrBlank()) {
            Log.e("ReviewFragment", "User is not authenticated.")
            showError("Please log in again.")
            showLoading(false)
            return
        }

        Log.d("ReviewFragment", "Fetching reviews for doctorId: $doctorId")

        val query: Query = FirebaseDatabase.getInstance("https://appmilestone2-default-rtdb.europe-west1.firebasedatabase.app")
            .reference.child("review_items")
            .orderByChild("doctorId")
            .equalTo(doctorId)

        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) {
                    Log.w("ReviewFragment", "No reviews found for doctorId: $doctorId")
                    showEmptyState(true)
                    showLoading(false)
                    return
                }

                reviewItems.clear()
                for (itemSnapshot in snapshot.children) {
                    val reviewItem = itemSnapshot.getValue(ReviewItem::class.java)
                    if (reviewItem != null) {
                        reviewItems.add(reviewItem)
                        Log.d("ReviewFragment", "Loaded review item: $reviewItem")
                    }
                }

                reviewAdapter.notifyDataSetChanged()
                showEmptyState(reviewItems.isEmpty())
                showLoading(false)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("ReviewFragment", "Database error: ${error.message}", error.toException())
                showError("Failed to load reviews: ${error.message}")
                showLoading(false)
            }
        })
    }

    private fun updateReviewStatus(reviewItem: ReviewItem, status: String) {
        val reviewRef = FirebaseDatabase.getInstance("https://appmilestone2-default-rtdb.europe-west1.firebasedatabase.app")
            .reference.child("review_items").child(reviewItem.id)

        reviewRef.child("status").setValue(status)
            .addOnSuccessListener {
                Toast.makeText(requireContext(), "Request $status successfully.", Toast.LENGTH_SHORT).show()
                updateLocalReviewItem(reviewItem, status)
            }
            .addOnFailureListener {
                Log.e("ReviewFragment", "Failed to update status: ${it.message}")
                showError("Failed to update status: ${it.message}")
            }
    }

    private fun handleRespondAction(reviewItem: ReviewItem) {
        val response = "Doctor's response text"
        val reviewRef = FirebaseDatabase.getInstance("https://appmilestone2-default-rtdb.europe-west1.firebasedatabase.app")
            .reference.child("review_items").child(reviewItem.id)

        reviewRef.child("response").setValue(response)
            .addOnSuccessListener {
                reviewRef.child("status").setValue("answered")
                    .addOnSuccessListener {
                        Toast.makeText(requireContext(), "Response saved successfully.", Toast.LENGTH_SHORT).show()
                        updateLocalReviewItem(reviewItem, "answered", response)
                    }
            }
            .addOnFailureListener {
                Log.e("ReviewFragment", "Failed to save response: ${it.message}")
                showError("Failed to save response: ${it.message}")
            }
    }

    private fun updateLocalReviewItem(reviewItem: ReviewItem, status: String, response: String? = null) {
        val index = reviewItems.indexOf(reviewItem)
        if (index != -1) {
            reviewItems[index].status = status
            if (response != null) {
                reviewItems[index].response = response
            }
            reviewAdapter.notifyItemChanged(index)
        }
    }

    private fun showEmptyState(isEmpty: Boolean) {
        binding.emptyStateText.visibility = if (isEmpty) View.VISIBLE else View.GONE
    }

    private fun showLoading(show: Boolean) {
        binding.loadingSpinner.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun showError(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }
}
