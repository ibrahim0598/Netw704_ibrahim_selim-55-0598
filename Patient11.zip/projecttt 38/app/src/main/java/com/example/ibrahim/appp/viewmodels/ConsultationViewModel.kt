package com.example.ibrahim.appp.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.ibrahim.appp.models.ConsultationRequest as Consultation

class ConsultationViewModel : ViewModel() {

    private val _consultations = MutableLiveData<MutableList<Consultation>>(mutableListOf())
    val consultations: LiveData<MutableList<Consultation>> get() = _consultations

    fun addConsultation(consultation: Consultation) {
        val currentConsultations = _consultations.value ?: mutableListOf()
        currentConsultations.add(consultation)
        _consultations.value = currentConsultations
    }

    fun loadConsultationHistory() {
        // Simulate loading data (replace with actual database fetching logic)
        _consultations.value = mutableListOf(
            Consultation("1", "2024-11-20", "Pending", "Awaiting response"),
            Consultation("2", "2024-11-18", "Completed", "Consultation completed successfully")
        )
    }
}
