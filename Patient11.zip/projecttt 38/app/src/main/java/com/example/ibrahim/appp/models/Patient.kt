package com.example.ibrahim.appp.models

// Patient.kt

data class Patient(
    val id: String = "",
    val name: String = "",
    val email: String = "",
    val medications: List<String> = emptyList()
)
