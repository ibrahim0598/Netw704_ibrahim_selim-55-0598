package com.example.ibrahim.appp.models

data class ConsultationRequest(
    val id: String = "",
    val status: String = "",
    val response: String = "",
    val date: String = "",
    val patientId: String = "" // Add this field
)
