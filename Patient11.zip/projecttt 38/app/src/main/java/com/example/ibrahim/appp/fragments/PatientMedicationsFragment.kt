package com.example.ibrahim.appp.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.GridLayoutManager
import com.example.ibrahim.appp.adapters.MedicationAdapter
import com.example.ibrahim.appp.databinding.FragmentPatientMedicationsBinding
import com.example.ibrahim.appp.models.Medication
import com.example.ibrahim.appp.viewmodels.CartViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class PatientMedicationsFragment : Fragment() {

    private var _binding: FragmentPatientMedicationsBinding? = null
    private val binding get() = _binding!!

    private val medications = mutableListOf<Medication>() // List of medications
    private val cartViewModel: CartViewModel by activityViewModels() // Shared ViewModel for cart
    private lateinit var database: DatabaseReference // Firebase Realtime Database reference
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    private lateinit var adapter: MedicationAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPatientMedicationsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize Firebase Realtime Database
        database = FirebaseDatabase.getInstance("https://appmilestone2-default-rtdb.europe-west1.firebasedatabase.app")
            .reference.child("medications")

        // Set up RecyclerView
        setupRecyclerView()

        // Fetch medications from Firebase
        fetchMedicationItems()
    }

    private fun fetchMedicationItems() {
        // Show loading indicator while fetching the data
        showLoading(true)

        val patientId = auth.currentUser?.uid
        if (patientId.isNullOrBlank()) {
            // Log error if user is not authenticated
            Log.e("PatientMedicationsFragment", "User is not authenticated.")
            showError("Please log in again.")
            showLoading(false)
            return
        }

        // Log patient ID for debugging
        Log.d("PatientMedicationsFragment", "Fetching medications for patientId: $patientId")

        // Reference to Firebase Realtime Database for medications
        val query: Query = database.orderByChild("patientId").equalTo(patientId)

        // Fetch data with a single value event listener
        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // If no medications are found for this patient
                if (!snapshot.exists()) {
                    Log.w("PatientMedicationsFragment", "No medications found for patientId: $patientId")
                    showEmptyState(true)  // Show empty state UI
                    showLoading(false)  // Hide loading spinner
                    return
                }

                // Clear the existing list of medications
                medications.clear()

                // Loop through each medication item in the snapshot
                for (itemSnapshot in snapshot.children) {
                    val medication = itemSnapshot.getValue(Medication::class.java)  // Deserialize to Medication model
                    if (medication != null) {
                        medications.add(medication)  // Add the medication to the list
                        Log.d("PatientMedicationsFragment", "Loaded medication item: $medication")
                    }
                }

                // Notify the adapter to update the UI with new data
                adapter.notifyDataSetChanged()

                // Check if the list is empty and show empty state if necessary
                showEmptyState(medications.isEmpty())
                showLoading(false)  // Hide loading spinner
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle Firebase database error
                Log.e("PatientMedicationsFragment", "Error fetching medications: ${error.message}")
                showError("Failed to load medications. Please try again.")
                showLoading(false)  // Hide loading spinner in case of failure
            }
        })
    }

    private fun setupRecyclerView() {
        // Create the adapter and handle callbacks
        adapter = MedicationAdapter(
            medications = medications,
            onApprovalRequest = { medication ->
                // Handle "Request Approval" action
                Toast.makeText(
                    requireContext(),
                    "Approval requested for ${medication.name}",
                    Toast.LENGTH_SHORT
                ).show()
            },
            onAddToCart = { medication ->
                // Add medication to cart via ViewModel
                if (medication.quantity > 0) {
                    cartViewModel.addToCart(medication.copy()) // Add to shared ViewModel
                    Toast.makeText(
                        requireContext(),
                        "${medication.quantity} x ${medication.name} added to cart.",
                        Toast.LENGTH_SHORT
                    ).show()

                    // Reset quantity after adding to cart
                    medication.quantity = 0
                    adapter.notifyDataSetChanged() // Refresh RecyclerView
                } else {
                    // Warn user if quantity is zero
                    Toast.makeText(
                        requireContext(),
                        "Please select a quantity before adding to cart.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
            isDoctor = false // This fragment is for patients
        )

        // Set up the RecyclerView
        binding.medicationsRecyclerView.layoutManager = GridLayoutManager(requireContext(), 2)
        binding.medicationsRecyclerView.adapter = adapter
    }

    private fun showEmptyState(isEmpty: Boolean) {
        binding.emptyStateText.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.medicationsRecyclerView.visibility = if (isEmpty) View.GONE else View.VISIBLE
    }

    private fun showLoading(show: Boolean) {
        binding.loadingSpinner.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun showError(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
