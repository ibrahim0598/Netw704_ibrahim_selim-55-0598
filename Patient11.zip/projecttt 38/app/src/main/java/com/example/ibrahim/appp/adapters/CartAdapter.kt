package com.example.ibrahim.appp.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.ibrahim.appp.databinding.ItemMedicationBinding
import com.example.ibrahim.appp.models.Medication

class CartAdapter(
    val items: MutableList<Medication>, // Mutable list for dynamic updates
    private val onDecrement: (Medication) -> Unit, // Callback for decrementing quantity
    private val onRemove: (Medication) -> Unit // Callback for item removal
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val binding = ItemMedicationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CartViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val item = items[position]
        holder.bind(item)
    }

    override fun getItemCount(): Int = items.size

    inner class CartViewHolder(private val binding: ItemMedicationBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(medication: Medication) {
            // Set medication name and price
            binding.medicationDescriptionTextView.text = medication.name
            binding.medicationPriceTextView.text = "Price: $${String.format("%.2f", medication.price * medication.quantity)}"

            // Show quantity
            binding.quantityTextView.visibility = View.VISIBLE
            binding.quantityTextView.text = medication.quantity.toString()

            // Handle Decrement Button
            binding.decreaseButton.visibility = View.VISIBLE
            binding.decreaseButton.setOnClickListener {
                if (medication.quantity > 1) {
                    medication.quantity -= 1
                    notifyItemChanged(adapterPosition) // Update RecyclerView
                    onDecrement(medication) // Trigger callback
                } else {
                    // If quantity is 1, consider removing the item instead
                    items.removeAt(adapterPosition)
                    notifyItemRemoved(adapterPosition)
                    onRemove(medication)
                }
            }

            // Hide Increase Button (Cart only allows decrement)
            binding.increaseButton.visibility = View.GONE

            // Handle Remove Button
            binding.actionButton.text = "Remove"
            binding.actionButton.visibility = View.VISIBLE
            binding.actionButton.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    val removedItem = items[position]
                    items.removeAt(position) // Remove item
                    notifyItemRemoved(position) // Notify RecyclerView of removal
                    onRemove(removedItem) // Trigger the callback for further logic
                }
            }
        }
    }
}
