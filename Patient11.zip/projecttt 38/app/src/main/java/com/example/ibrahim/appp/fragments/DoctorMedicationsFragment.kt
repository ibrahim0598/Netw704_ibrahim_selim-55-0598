package com.example.ibrahim.appp.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.example.ibrahim.appp.R
import com.example.ibrahim.appp.adapters.DoctorMedicationAdapter
import com.example.ibrahim.appp.databinding.FragmentDoctorMedicationsBinding
import com.example.ibrahim.appp.models.DoctorMedication
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class DoctorMedicationsFragment : Fragment() {

    private var _binding: FragmentDoctorMedicationsBinding? = null
    private val binding get() = _binding!!

    private val medications = mutableListOf<DoctorMedication>() // List of medications
    private lateinit var database: DatabaseReference // Firebase Realtime Database reference
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()

    private lateinit var adapter: DoctorMedicationAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDoctorMedicationsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize Firebase Realtime Database with the correct URL
        database = FirebaseDatabase.getInstance("https://appmilestone2-default-rtdb.europe-west1.firebasedatabase.app")
            .getReference("medications")

        // Set up RecyclerView
        setupRecyclerView()

        // Fetch medications from Firebase
        fetchMedicationItems()
    }

    private fun fetchMedicationItems() {
        // Show loading indicator while fetching the data
        showLoading(true)

        val doctorId = auth.currentUser?.uid
        if (doctorId.isNullOrBlank()) {
            // Log error if user is not authenticated
            Log.e("DoctorMedicationsFragment", "User is not authenticated.")
            showError("Please log in again.")
            showLoading(false)
            return
        }

        // Log doctor ID for debugging
        Log.d("DoctorMedicationsFragment", "Fetching medications for doctorId: $doctorId")

        // Reference to Firebase Realtime Database for medications
        val query: Query = FirebaseDatabase.getInstance("https://appmilestone2-default-rtdb.europe-west1.firebasedatabase.app")
            .reference.child("medications")  // Ensure the correct reference for medications
            .orderByChild("doctorId")  // Query by doctorId
            .equalTo(doctorId)  // Filter to only the doctor’s medications

        // Fetch data with a single value event listener
        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // If no medications are found for this doctor
                if (!snapshot.exists()) {
                    Log.w("DoctorMedicationsFragment", "No medications found for doctorId: $doctorId")
                    showEmptyState(true)  // Show empty state UI
                    showLoading(false)  // Hide loading spinner
                    return
                }

                // Clear the existing list of medications
                medications.clear()

                // Loop through each medication item in the snapshot
                for (itemSnapshot in snapshot.children) {
                    val medication = itemSnapshot.getValue(DoctorMedication::class.java)  // Deserialize to Medication model
                    if (medication != null) {
                        medications.add(medication)  // Add the medication to the list
                        Log.d("DoctorMedicationsFragment", "Loaded medication item: $medication")
                    }
                }

                // Notify the adapter to update the UI with new data
                adapter.notifyDataSetChanged()

                // Show the RecyclerView and hide the empty state
                binding.medicationsRecyclerView.visibility = if (medications.isNotEmpty()) View.VISIBLE else View.GONE
                showEmptyState(medications.isEmpty()) // If the list is empty, show empty state
                showLoading(false)  // Hide loading spinner
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle Firebase database error
                Log.e("DoctorMedicationsFragment", "Error fetching medications: ${error.message}")
                showError("Failed to load medications. Please try again.")
                showLoading(false)  // Hide loading spinner in case of failure
            }
        })
    }

    private fun setupRecyclerView() {
        // Create the adapter and handle callbacks
        adapter = DoctorMedicationAdapter(
            medications = medications,
            onAddMedication = { medication ->
                // Handle adding new medication to Firebase
                addMedicationToFirebase(medication)
            },
            onEditMedication = { medication ->
                // Handle editing medication (editing only name and quantity)
                editMedicationInFirebase(medication)
            },
            onDeleteMedication = { medication ->
                // Handle deleting medication from Firebase
                deleteMedicationFromFirebase(medication)
            }
        )

        // Set up the RecyclerView with a GridLayoutManager (2 columns)
        binding.medicationsRecyclerView.layoutManager = GridLayoutManager(requireContext(), 2)
        binding.medicationsRecyclerView.adapter = adapter
    }

    private fun addMedicationToFirebase(medication: DoctorMedication) {
        val doctorId = auth.currentUser?.uid
        if (doctorId.isNullOrBlank()) {
            showError("Doctor not authenticated")
            return
        }

        // Add the medication with a new key
        val medicationId = database.push().key ?: return

        val newMedication = medication.copy(id = medicationId, doctorId = doctorId)
        database.child(medicationId).setValue(newMedication)
            .addOnSuccessListener {
                Toast.makeText(requireContext(), "Medication added successfully", Toast.LENGTH_SHORT).show()
                medications.add(newMedication) // Add to the list and update UI
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                showError("Failed to add medication")
            }
    }

    private fun editMedicationInFirebase(medication: DoctorMedication) {
        val doctorId = auth.currentUser?.uid
        if (doctorId.isNullOrBlank()) {
            showError("Doctor not authenticated")
            return
        }

        val medicationId = medication.id
        if (medicationId.isNullOrBlank()) {
            showError("Invalid medication ID")
            return
        }

        // Update only the name and quantity
        val updatedMedication = medication.copy(name = medication.name, quantity = medication.quantity)

        database.child(medicationId).setValue(updatedMedication)
            .addOnSuccessListener {
                Toast.makeText(requireContext(), "Medication updated successfully", Toast.LENGTH_SHORT).show()
                medications.find { it.id == medicationId }?.apply {
                    name = updatedMedication.name
                    quantity = updatedMedication.quantity
                }
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                showError("Failed to update medication")
            }
    }

    private fun deleteMedicationFromFirebase(medication: DoctorMedication) {
        val medicationId = medication.id
        if (medicationId.isNullOrBlank()) {
            showError("Invalid medication ID")
            return
        }

        database.child(medicationId).removeValue()
            .addOnSuccessListener {
                Toast.makeText(requireContext(), "Medication deleted successfully", Toast.LENGTH_SHORT).show()
                medications.remove(medication) // Remove from the list and update UI
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                showError("Failed to delete medication")
            }
    }

    private fun showEmptyState(isEmpty: Boolean) {
        binding.emptyStateText.visibility = if (isEmpty) View.VISIBLE else View.GONE
    }

    private fun showLoading(show: Boolean) {
        binding.loadingSpinner.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun showError(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
