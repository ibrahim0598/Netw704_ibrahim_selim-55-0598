package com.example.ibrahim.appp.models

import com.google.firebase.database.PropertyName

data class ReviewItem(
    val id: String = "", // Unique identifier for the request
    val requestType: String = "", // Type of the request (e.g., "Medication", "Consultation")
    val details: String = "", // Additional details about the request
    var status: String = "", // Current status of the request (e.g., "pending", "approved", "declined", "answered")

    @get:PropertyName("isMedicationRequest") @set:PropertyName("isMedicationRequest")
    var isMedicationRequest: Boolean = false, // Indicates if the request is for medication

    @get:PropertyName("isConsultationRequest") @set:PropertyName("isConsultationRequest")
    var isConsultationRequest: Boolean = false, // Indicates if the request is for consultation

    val doctorId: String = "", // The doctor's unique identifier (matches Firebase field)

    @get:PropertyName("response") @set:PropertyName("response")
    var response: String? = null // The doctor's response to the review
)
