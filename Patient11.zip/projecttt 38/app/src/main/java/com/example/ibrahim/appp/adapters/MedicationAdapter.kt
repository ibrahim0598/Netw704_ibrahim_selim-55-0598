package com.example.ibrahim.appp.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.ibrahim.appp.databinding.ItemMedicationBinding
import com.example.ibrahim.appp.models.Medication

class MedicationAdapter(
    private val medications: MutableList<Medication>,
    private val onApprovalRequest: (Medication) -> Unit,
    private val onAddToCart: (Medication) -> Unit,
    private val isDoctor: Boolean // Determines doctor vs patient behavior
) : RecyclerView.Adapter<MedicationAdapter.MedicationViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MedicationViewHolder {
        val binding = ItemMedicationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MedicationViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MedicationViewHolder, position: Int) {
        val medication = medications[position]
        holder.bind(medication)
    }

    override fun getItemCount(): Int = medications.size

    inner class MedicationViewHolder(private val binding: ItemMedicationBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(medication: Medication) {
            // Use Glide to load images for better performance and network image support
            Glide.with(binding.root.context)
                .load(medication.imageResId) // Assuming you are using a local placeholder image
                .into(binding.medicationImageView)

            binding.medicationDescriptionTextView.text = medication.name

            // Update visibility of options and initial UI state
            updateOptionsVisibility(medication)

            // Increase Quantity
            binding.increaseButton.setOnClickListener {
                medication.quantity++
                notifyItemChanged(adapterPosition) // Refresh item
            }

            // Decrease Quantity
            binding.decreaseButton.setOnClickListener {
                if (medication.quantity > 0) {
                    medication.quantity--
                    notifyItemChanged(adapterPosition) // Refresh item
                }
            }

            // Handle action button logic dynamically based on user role
            binding.actionButton.setOnClickListener {
                if (isDoctor) {
                    // Doctor's approval workflow
                    onApprovalRequest(medication)
                } else {
                    // Patient's add-to-cart or request-approval workflow
                    if (medication.isApproved) {
                        onAddToCart(medication)
                        notifyItemChanged(adapterPosition) // Refresh item after adding to cart
                    } else {
                        onApprovalRequest(medication) // Request approval if not approved
                    }
                }
            }
        }

        private fun updateOptionsVisibility(medication: Medication) {
            // Show options if quantity > 0, otherwise hide them
            binding.optionsContainer.visibility = if (medication.quantity > 0) View.VISIBLE else View.GONE

            // Update displayed price
            binding.medicationPriceTextView.text = "Price: $${String.format("%.2f", medication.price * medication.quantity)}"

            // Update action button text based on role and approval status
            binding.actionButton.text = when {
                isDoctor -> "Approve Medication"
                medication.isApproved -> "Add to Cart"
                else -> "Request Approval"
            }

            // Update displayed quantity
            binding.quantityTextView.text = medication.quantity.toString()
        }
    }
}
