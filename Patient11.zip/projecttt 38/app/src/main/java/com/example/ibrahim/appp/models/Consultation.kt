package com.example.ibrahim.appp.models

data class Consultation(
    val id: String = "",
    val patientName: String = "",
    val doctorName: String = "",
    val time: String = "", // ISO 8601 format
    val status: String = "",
    val notes: String = ""
)

