package com.example.ibrahim.appp.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ibrahim.appp.databinding.ActivityLoginBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance("https://appmilestone2-default-rtdb.europe-west1.firebasedatabase.app")
            .reference.child("users")

        // Handle the login button click
        binding.loginButton.setOnClickListener {
            val email = binding.emailEditText.text.toString()
            val password = binding.passwordEditText.text.toString()

            // Sign in the user using Firebase Authentication
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        // Get the current user
                        val user = auth.currentUser
                        val userId = user?.uid

                        if (userId != null) {
                            // Get the user role from the database
                            getUserRole(userId)
                        }
                    } else {
                        Toast.makeText(baseContext, "Authentication failed.", Toast.LENGTH_SHORT).show()
                    }
                }
        }

        // Navigate to RegisterActivity if user needs to register
        binding.registerButton.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun getUserRole(userId: String) {
        // Get the user role from the Firebase database
        database.child(userId).child("role").get().addOnSuccessListener { snapshot ->
            val userRole = snapshot.value as? String

            if (userRole != null) {
                // Redirect to the appropriate home screen based on the role
                navigateToHomeActivity(userRole)
            } else {
                Toast.makeText(baseContext, "User role not found.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun navigateToHomeActivity(userRole: String) {
        // Navigate to HomeActivity based on the user role (Doctor or Patient)
        val intent = Intent(this, HomeActivity::class.java)
        intent.putExtra("USER_TYPE", userRole.capitalize()) // Pass the role to HomeActivity
        startActivity(intent)
        finish()
    }
}
