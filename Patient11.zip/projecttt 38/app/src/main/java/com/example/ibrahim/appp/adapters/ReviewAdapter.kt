package com.example.ibrahim.appp.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ibrahim.appp.R
import com.example.ibrahim.appp.models.ReviewItem
import com.google.android.material.button.MaterialButton

class ReviewAdapter(
    private val reviewItems: List<ReviewItem>,
    private val onActionClickListener: (ReviewItem, Action) -> Unit
) : RecyclerView.Adapter<ReviewAdapter.ReviewViewHolder>() {

    // Enum for the types of actions that can be performed
    enum class Action { APPROVE, DECLINE, RESPOND }

    // ViewHolder class to represent a single item view
    inner class ReviewViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val requestTypeTextView: TextView = itemView.findViewById(R.id.requestTypeTextView)
        val statusTextView: TextView = itemView.findViewById(R.id.statusTextView)
        val detailsTextView: TextView = itemView.findViewById(R.id.detailsTextView)
        val approveButton: MaterialButton = itemView.findViewById(R.id.approveButton)
        val declineButton: MaterialButton = itemView.findViewById(R.id.declineButton)
        val respondButton: MaterialButton = itemView.findViewById(R.id.respondButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReviewViewHolder {
        // Inflate the layout for individual review items
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.review_item, parent, false)
        return ReviewViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ReviewViewHolder, position: Int) {
        val reviewItem = reviewItems[position]

        // Bind review item data to the UI elements
        holder.requestTypeTextView.text = reviewItem.requestType.ifBlank { "N/A" }
        holder.statusTextView.text = "Status: ${reviewItem.status.replaceFirstChar { it.uppercase() }}"
        holder.detailsTextView.text = reviewItem.details.ifBlank { "No details provided." }

        // Set visibility for action buttons based on the request type
        holder.approveButton.visibility = if (reviewItem.isMedicationRequest) View.VISIBLE else View.GONE
        holder.declineButton.visibility = if (reviewItem.isMedicationRequest) View.VISIBLE else View.GONE
        holder.respondButton.visibility = if (reviewItem.isConsultationRequest) View.VISIBLE else View.GONE

        // Handle button clicks
        holder.approveButton.setOnClickListener {
            onActionClickListener(reviewItem, Action.APPROVE)
        }
        holder.declineButton.setOnClickListener {
            onActionClickListener(reviewItem, Action.DECLINE)
        }
        holder.respondButton.setOnClickListener {
            onActionClickListener(reviewItem, Action.RESPOND)
        }
    }

    override fun getItemCount(): Int = reviewItems.size

    // Optional: Handle item visibility in a more consistent way
    private fun setItemVisibility(holder: ReviewViewHolder, isVisible: Boolean) {
        holder.itemView.visibility = if (isVisible) View.VISIBLE else View.GONE
    }
}
