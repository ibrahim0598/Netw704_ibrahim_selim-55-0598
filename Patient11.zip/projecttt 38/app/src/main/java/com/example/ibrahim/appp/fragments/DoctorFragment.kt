package com.example.ibrahim.appp.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ibrahim.appp.adapters.MedicationAdapter
import com.example.ibrahim.appp.databinding.FragmentDoctorBinding
import com.example.ibrahim.appp.models.Medication
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class DoctorFragment : Fragment() {

    private var _binding: FragmentDoctorBinding? = null
    private val binding get() = _binding!!

    private lateinit var database: DatabaseReference

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDoctorBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        database = FirebaseDatabase.getInstance().reference.child("medications")

        binding.addMedicationButton.setOnClickListener {
            addNewMedication()
        }

        loadMedications()
    }

    private fun addNewMedication() {
        val medicationId = database.push().key ?: return
        val newMedication = Medication(
            id = medicationId,
            name = "New Medication",
            price = 100.0
        )
        database.child(medicationId).setValue(newMedication)
            .addOnSuccessListener {
                Toast.makeText(context, "Medication added", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(context, "Failed to add medication", Toast.LENGTH_SHORT).show()
            }
    }

    private fun loadMedications() {
        database.get().addOnSuccessListener { snapshot ->
            val medications = mutableListOf<Medication>()
            snapshot.children.mapNotNullTo(medications) {
                it.getValue(Medication::class.java)
            }

            val medicationAdapter = MedicationAdapter(
                medications = medications,
                onApprovalRequest = { medication ->
                    Toast.makeText(requireContext(), "Approval requested for: ${medication.name}", Toast.LENGTH_SHORT).show()
                },
                onAddToCart = { medication ->
                    Toast.makeText(requireContext(), "Added to cart: ${medication.name}", Toast.LENGTH_SHORT).show()
                },
                isDoctor = true
            )

            binding.medicationRecyclerView.layoutManager = LinearLayoutManager(requireContext())
            binding.medicationRecyclerView.adapter = medicationAdapter
        }.addOnFailureListener {
            Toast.makeText(requireContext(), "Failed to load medications", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
